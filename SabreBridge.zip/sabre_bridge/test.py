import win32com.client
com = win32com.client.Dispatch("zkemkeeper.ZKEM.1")
print("Created:", com)
